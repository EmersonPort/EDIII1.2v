#ifndef _IO_METRO_
#define _IO_METRO_

#include <stdio.h>
#include <stdlib.h>
#include "../defines.h"

void aplicacao1(FILE* file1,FILE* file2);
void aplicacao2(FILE* file);
void aplicacao3(FILE* file);
void aplicacao4(FILE* file);
void aplicacao5(FILE* file);
void aplicacao6(FILE* file);
#endif