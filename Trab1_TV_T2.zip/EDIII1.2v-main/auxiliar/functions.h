#ifndef _functions_
#define _functions_

void readline(char* string);
void binarioNaTela(char *nomeArquivoBinario);
void scan_quote_string(char *str);

#endif